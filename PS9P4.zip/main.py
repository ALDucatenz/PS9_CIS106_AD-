def compavg(game1,game2,game3,hand):
  global avg
  avg = (game1 + game2 + game3)/3
  
  global avgh
  avgh = avg + hand

  return avg, avgh

name = input("Enter Last name: ")

game1 = float(input("Enter game 1 score: "))
game2 = float(input("Enter game 2 score: "))
game3 = float(input("Enter game 3 score: "))

hand = float(input("Enter handicap: "))

compavg(game1,game2,game3,hand)

print("Average bowling score: ",avg)
print("Average bowling score with handicap: ", avgh)