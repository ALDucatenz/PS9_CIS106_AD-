def comptotal(qty,price):
  global total
  total = qty * price

  global tax
  tax = total * .07

  return total, tax

qty = float(input("Enter quantity: "))

price = float(input("Enter Unit price: $"))

comptotal(qty,price)

print("Total is $", total)
print("Tax is $", tax)
