def compscore(exam1,exam2,exam3):
  global avg
  avg = (exam1 + exam2 + exam3)/3
  global total
  total = (exam1 + exam2+ exam3)

  return avg, total

name = input("Enter last name: ")

exam1 = float(input("Enter Exam 1: "))
exam2 = float(input("Enter Exam 2: "))
exam3 = float(input("Enter Exam 3: "))

compscore(exam1,exam2,exam3)

print("Average exam score: ", avg)

print("Total exam points: ",total)

