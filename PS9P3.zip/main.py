def comp(sales):
  
  global comm
  if float(sales) > 100000:
    comm = float(sales) * .1
  else:
    comm = float(sales) * .05
  

  global target
  target = float(sales) * 1.05

  return comm, target

name = input("Enter last name: ")

sales = input("Enter sales: $")

comp(sales)

print(name,", Your commision is $", comm)

print("Next year's target sales is $",target)

