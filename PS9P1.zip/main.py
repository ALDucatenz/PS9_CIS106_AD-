def compdiscount(quantity,price,rate):
  global amount 
  amount = (float(quantity) * float(price)) * float(rate)
  global discount
  discount = (float(quantity) * float(price)) - amount

  return amount, discount 

quantity = input("Enter quantity: ")
price = input("Enter price: $")
rate = input("Enter discount rate: ")

compdiscount(quantity,price,rate)

print("Discount amount: $", amount)
print("Discount price: $", discount)
